# Copyright 2015 IBM Corp. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import json
import sys
#import requests  #http://docs.python-requests.org/en/master/
from flask import request
from flask import Flask, jsonify, render_template, redirect, session, url_for
import watson_developer_cloud

#from watson_developer_cloud import ToneAnalyzerV3

import credentials
from credentials import tone_analyzer


app = Flask(__name__)

app.config.update(
    DEBUG=True,
)

		
def formatedoutput(data):
    print ("----------------------------------------------------------------------")
    print("Output from the Watson Tone Analyzer Service running on IBM Bluemix: \n")
    for i in data['document_tone']['tone_categories']:
        print(i['category_name'])
        print("-" * len(i['category_name']))
        for j in i['tones']:
            print(j['tone_name'].ljust(20),(str(round(j['score'] * 100,1)) + "%").rjust(10))
        print()
    print()	


@app.route('/')
def welcome():
#    return 'Welcome to flask and Cloudant on Bluemix.'
	return app.send_static_file('index.html')

#=======================================================
#
#=======================================================

@app.route('/minappform', methods = ['POST'])
def minappform():

    tone = request.form['toneinput']    
    data = json.dumps(tone_analyzer.tone(tone), indent=3)
    data = json.loads(data)
	 
    #datastring=str(data)
	 
	   
	# for i in data['document_tone']['tone_categories']:
    #    print(i['category_name'])
    #   print("-" * len(i['category_name']))
    #    for j in i['tones']:
    #        print(j['tone_name'].ljust(20),(str(round(j['score'] * 100,1)) + "%").rjust(10))
    #    print()
    #print()	  
	   
	    
	   
    return render_template('template1.html', watson= data )

	
#    data = json.dumps(tone_analyzer.tone(inputtext), indent=2)
#    data = json.loads(str(data))

#    formatedoutput(data)		
	
    

    return tone
	  
		

 #------------------------------------------------------------------------------------
 #
 #------------------------------------------------------------------------------------
 
port = os.getenv('VCAP_APP_PORT', '5000')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=int(port))
#
# Tone Analyzer Credentials
#
from watson_developer_cloud import ToneAnalyzerV3

tone_analyzer = ToneAnalyzerV3(
    username = '483f622d-06ab-44a8-bdfc-d8582c1c2d0c',
    password = 'IuTz4eCmxrf5',
    version='2016-05-19 ')